# Source Generated with Decompyle++
# File: netrc.pyc (Python 3.11)

'''An object-oriented interface to .netrc files.'''
import os
import shlex
import stat
__all__ = [
    'netrc',
    'NetrcParseError']

class NetrcParseError(Exception):
    '''Exception raised on syntax errors in the .netrc file.'''
    
    def __init__(self, msg, filename, lineno = (None, None)):
        self.filename = filename
        self.lineno = lineno
        self.msg = msg
        Exception.__init__(self, msg)

    
    def __str__(self):
        return f'''{self.msg!s} ({self.filename!s}, line {self.lineno!s})'''



class _netrclex:
    
    def __init__(self, fp):
        self.lineno = 1
        self.instream = fp
        self.whitespace = '\n\t\r '
        self.pushback = []

    
    def _read_char(self):
        ch = self.instream.read(1)
    # WARNING: Decompyle incomplete

    
    def get_token(self):
        if self.pushback:
            return self.pushback.pop(0)
        token = None
        fiter = iter(self._read_char, '')
    # WARNING: Decompyle incomplete

    
    def push_token(self, token):
        self.pushback.append(token)



class netrc:
    
    def __init__(self, file = (None,)):
        default_netrc = file is None
    # WARNING: Decompyle incomplete

    
    def _parse(self, file, fp, default_netrc):
        lexer = _netrclex(fp)
        saved_lineno = lexer.lineno
    # WARNING: Decompyle incomplete

    
    def _security_check(self, fp, default_netrc, login):
        pass
    # WARNING: Decompyle incomplete

    
    def authenticators(self, host):
        '''Return a (user, account, password) tuple for given host.'''
        if host in self.hosts:
            return self.hosts[host]
        if None in self.hosts:
            return self.hosts['default']

    
    def __repr__(self):
        '''Dump the class data in the format of a .netrc file.'''
        rep = ''
    # WARNING: Decompyle incomplete


if __name__ == '__main__':
    print(netrc())
    return None
