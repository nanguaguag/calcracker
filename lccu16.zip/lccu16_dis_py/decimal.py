# Source Generated with Decompyle++
# File: decimal.pyc (Python 3.11)

from _decimal import *
from _decimal import __doc__
from _decimal import __version__
from _decimal import __libmpdec_version__
return None
# WARNING: Decompyle incomplete
