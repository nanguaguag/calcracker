# Source Generated with Decompyle++
# File: llc_controller.pyc (Python 3.11)

'''
Tool controller for llc
'''
import common
LLC_OPTION_INCLUDE_SEARCH_PATH = '-I='
LLC_OPTION_OPTIMIZE = '-O'
LLC_OPTION_OPTIMIZE_0 = '0'
LLC_OPTION_OPTIMIZE_2 = '2'
LLC_OPTION_OPTIMIZE_3 = '3'
LLC_OPTION_CODE_MODEL = '-code-model='
LLC_OPTION_CODE_MODEL_SMALL = 'small'
LLC_OPTION_CODE_MODEL_LARGE = 'large'
LLC_OPTION_DATA_MODEL = '-data-model='
LLC_OPTION_DATA_MODEL_NEAR = 'near'
LLC_OPTION_DATA_MODEL_FAR = 'far'
LLC_OPTION_DWARF_VERSION = '-dwarf-version='
LLC_OPTION_FATAL_WARNINGS = '-fatal-warnings'
LLC_OPTION_OUTPUT_FILE_TYPE = '-filetype='
LLC_OPTION_OUTPUT_FILE_TYPE_ASM = 'asm'
LLC_OPTION_OUTPUT_FILE_TYPE_OBJ = 'obj'
LLC_OPTION_ARCHITECTURE = '-march='
LLC_OPTION_ARCHITECTURE_U16 = 'U16'
LLC_OPTION_ARCHITECTURE_U8 = 'U8'
LLC_OPTION_MCPU = '-type='
LLC_OPTION_MTRIPLE = '-mtriple='
LLC_OPTION_MTRIPLE_U16_U8 = 'U16_U8CORE'
LLC_OPTION_MTRIPLE_U16_U8_N = 'U16_U8CORE_N'
LLC_OPTION_NO_WARN = '-no-warn'
LLC_OPTION_OUTPUT_FILE = '-o='
LLC_OPTION_EMIT_STACK_SIZE = '-stack-size-selection'
LLC_OPTION_HELP = '-help'
LLC_OPTION_HELP_LIST = '-help-lis'
LLC_OPTION_VERSION = '-version'
LLC_OPTION_OUTPUT_OMFU8_ASSEMBLY = '-lapisomf'
LLC_OPTION_USE_RTLU8_ASSEMBLY = '-lapisrtl'
LLC_OPTION_DISABLE_LSR = '-disable-lsr'
LLC_OPTION_ENABLE_FUNCTION_SECTIONS = '--function-sections'
LLC_OPTION_ENABLE_DATA_SECTIONS = '--data-sections'
LLC_COMMAND_NAME = 'llc-u16'

def execute(options, input_file):
    '''
    Executes llc.
    '''
    command_line = []
    command_line.append(LLC_COMMAND_NAME)
    command_line.extend(options)
    command_line.append(input_file)
    returncode = common.subprocess_execute(command_line)
    return returncode

