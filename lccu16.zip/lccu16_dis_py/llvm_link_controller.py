# Source Generated with Decompyle++
# File: llvm_link_controller.pyc (Python 3.11)

'''
Tool controller for llvm-link
'''
import common
LLVM_LINK_OPTION_OUTPUT_FILE = '-o='
LLVM_LINK_OPTION_HELP = '-help'
LLVM_LINK_OPTION_HELP_LIST = '-help-list'
LLVM_LINK_OPTION_VERSION = '-version'
LLVM_LINK_OPTION_SUPPRESS_WARNINGS = '-suppress-warnings'
LLVM_LINK_OPTION_S = '-S'
LLVM_LINK_COMMAND_NAME = 'llvm-link-u16'

def execute(options, input_files):
    '''
    Executes llvm-link
    '''
    command_line = []
    command_line.append(LLVM_LINK_COMMAND_NAME)
    command_line.extend(options)
    command_line.extend(input_files)
    returncode = common.subprocess_execute(command_line)
    return returncode

