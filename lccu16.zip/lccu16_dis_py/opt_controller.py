# Source Generated with Decompyle++
# File: opt_controller.pyc (Python 3.11)

'''
Tool controller for opt
'''
import common
OPT_OPTION_OPTIMIZE = '-O'
OPT_OPTION_OPTIMIZE_0 = '0'
OPT_OPTION_OPTIMIZE_2 = '2'
OPT_OPTION_OPTIMIZE_3 = '3'
OPT_OPTION_OPTIMIZE_Z = 'z'
OPT_OPTION_DOT_CALLGRAPH = '-dot-callgraph'
OPT_OPTION_DOT_CALLGRAPH_FILENAME = '--callgraph-dot-filename-prefix='
OPT_OPTION_CODE_MODEL = '-code-model='
OPT_OPTION_CODE_MODEL_SMALL = 'small'
OPT_OPTION_CODE_MODEL_LARGE = 'large'
OPT_OPTION_DATA_MODEL = '-data-model='
OPT_OPTION_DATA_MODEL_NEAR = 'near'
OPT_OPTION_DATA_MODEL_FAR = 'far'
OPT_OPTION_DWARF_VERSION = '-dwarf-version='
OPT_OPTION_FATAL_WARNINGS = '-fatal-warnings'
OPT_OPTION_ARCHITECTURE = '-march='
OPT_OPTION_ARCHITECTURE_U16 = 'U16'
OPT_OPTION_ARCHITECTURE_U8 = 'U8'
OPT_OPTION_MCPU = '-type='
OPT_OPTION_MTRIPLE = '-mtriple='
OPT_OPTION_MTRIPLE_U16_U8 = 'U16_U8CORE'
OPT_OPTION_MTRIPLE_U16_U8_N = 'U16_U8CORE_N'
OPT_OPTION_NO_WARN = '-no-warn'
OPT_OPTION_OUTPUT_FILE = '-o='
OPT_OPTION_HELP = '-help'
OPT_OPTION_HELP_LIST = '-help-lis'
OPT_OPTION_VERSION = '-version'
OPT_OPTION_PREPROCESS_AND_COMPILATION = '-S'
OPT_OPTION_DISABLE_LOOP_UNROLLING = '-disable-loop-unrolling'
OPT_COMMAND_NAME = 'opt-u16'

def execute(options, input_file):
    '''
    Executes opt.
    '''
    command_line = []
    command_line.append(OPT_COMMAND_NAME)
    command_line.extend(options)
    command_line.append(input_file)
    returncode = common.subprocess_execute(command_line)
    return returncode

