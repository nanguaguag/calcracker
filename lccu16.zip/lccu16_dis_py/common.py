# Source Generated with Decompyle++
# File: common.pyc (Python 3.11)

'''
Common contoller
'''
import os
import copy
import subprocess
import re
import sys
CDRV_KEY_TOOLCHAIN = 'toolchain'
CDRV_KEY_TOOLCHAIN_LCCU16 = 'lccu16'
CDRV_KEY_OUTPUT_DIR = 'output_dir'
CDRV_KEY_OUTPUT_FILENAME = 'output_filename'
CDRV_KEY_FILE_C = 'file_c'
CDRV_KEY_OPTION_LCCU16 = 'option_lccu16'
MESSAGE_TYPE_ERROR = 'error'
MESSAGE_TYPE_WARNING = 'warning'
MESSAGE_TYPE_MESSAGE = 'message'
MESSAGE_TYPE_LIST = {
    MESSAGE_TYPE_ERROR,
    MESSAGE_TYPE_WARNING}
RETURN_CODE_SUCCESS = 0
RETURN_CODE_FAILURE = 1
PARAM_KEY_COMMON = ''

def subprocess_execute(command_line):
    '''
    Executes subprocess.Popen() with the specified string list.
    '''
    print(' '.join(command_line))
    return_code = 0
# WARNING: Decompyle incomplete


def print_message(message_type, message):
    '''
    Outputs specified message.
    '''
    if message_type not in MESSAGE_TYPE_LIST:
        message_type = MESSAGE_TYPE_MESSAGE
    print_str = 'lccu16: {0}: {1}'.format(message_type, message)
    print(print_str)


def normpaths(paths):
    '''
    Normalizes all paths.
    '''
    ret = []
# WARNING: Decompyle incomplete


def normpath(path):
    '''
    Normalizes the path.
    '''
    ret = os.path.normpath(path)
    if not os.path.isabs(ret):
        if not ret.startswith('.'):
            ret = os.path.join('.', ret)
        elif ret == '.':
            ret += os.path.sep
    return ret


def parse_option_only(input_str, option, option_param):
    '''
    Parses if the string matches the specified option.
    '''
    if input_str == option:
        option_param.append((option, ''))
        return True


def parse_option_with_constant(input_str, option, option_param):
    '''
    Parses if the string matches the specified option.
    If they match, separate the options and parameters and check if the parameters are numerical.
    '''
    if input_str.startswith(option):
        param = input_str[len(option):]
        if param or param.isdigit():
            option_param.append((option, param))
            return True
        return None


def parse_option_with_string(input_str, option, option_param):
    '''
    Parses if the string matches the specified option.
    If they match, separate into options and parameters.
    '''
    if input_str.startswith(option):
        option_param.append((option, input_str[len(option):]))
        return True


def get_escape(escape_count):
    '''
    Gets specified number of escape.
    '''
    token = ''
    num = 0
# WARNING: Decompyle incomplete


def split_arguments(arg_strs):
    '''
    Separate the strings with spaces.
    '''
    argv = []
    escape_count = 0
    token_select = 0
    token = [
        '',
        '']
# WARNING: Decompyle incomplete


def parse_option_file(option_file_path):
    '''
    Analyzes the option setting file to get the option settings for each Toolchain, input file, and Tool.
    '''
    params = dict()
    if not os.path.isfile(option_file_path):
        return params
# WARNING: Decompyle incomplete


def update_params(params, key, sub_key, values):
    '''
    Updates the list of the specified "List classification"-"Subkey" in the information of the option setting file.
    '''
    sub_params = params.get(key)
# WARNING: Decompyle incomplete


def get_sub_params(params, key):
    '''
    Gets the dictionary of the specified "list classification" from the information in the option setting file.
    '''
    sub_params = params.get(key)
# WARNING: Decompyle incomplete


def get_sub_param_values(params, key, sub_key):
    '''
    Gets the specified list of "list classification"-"subkey" from the information in the option setting file.
    '''
    values = []
    sub_params = params.get(key)
# WARNING: Decompyle incomplete


def get_sub_param_top_value(params, key, sub_key, default):
    '''
    Gets the first element of the specified "list classification"-"subkey" list from the information in the option setting file.
    '''
    top = default
    values = get_sub_param_values(params, key, sub_key)
    if values:
        top = values[0]
    return top


def get_sub_param_top_value_all(params, key):
    '''
    Gets the first element of all "subkeys" of the specified "list classification" from the information in the option setting file.
    '''
    tops = dict()
    sub_params = params.get(key)
# WARNING: Decompyle incomplete


def split_file_path(file_path):
    '''
    split file path.
    '''
    head = ''
    root = ''
    ext = ''
    (head, tail) = os.path.split(file_path)
    if not head:
        head = './'
    if tail:
        (root, ext) = os.path.splitext(tail)
        if not ext:
            if root.startswith('.'):
                ext = root
                root = ''
            else:
                head = os.path.join(head, root)
                root = ''
    head = head.replace('\\', '/')
    if not head.endswith('/'):
        head += '/'
    if not os.path.isabs(head) and head.startswith('.'):
        head = './' + head
    root = root.replace('\\', '/')
    ext = ext.replace('\\', '/')
    return (head, root, ext)

