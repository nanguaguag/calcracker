# Source Generated with Decompyle++
# File: contextlib.pyc (Python 3.11)

'''Utilities for with-statement contexts.  See PEP 343.'''
import abc
import os
import sys
import _collections_abc
from collections import deque
from functools import wraps
from types import MethodType, GenericAlias
__all__ = [
    'asynccontextmanager',
    'contextmanager',
    'closing',
    'nullcontext',
    'AbstractContextManager',
    'AbstractAsyncContextManager',
    'AsyncExitStack',
    'ContextDecorator',
    'ExitStack',
    'redirect_stdout',
    'redirect_stderr',
    'suppress',
    'aclosing',
    'chdir']

class AbstractContextManager(abc.ABC):
    '''An abstract base class for context managers.'''
    __class_getitem__ = classmethod(GenericAlias)
    
    def __enter__(self):
        '''Return `self` upon entering the runtime context.'''
        return self

    __exit__ = (lambda self, exc_type, exc_value, traceback: pass)()
    __subclasshook__ = (lambda cls, C: if cls is AbstractContextManager:
_collections_abc._check_methods(C, '__enter__', '__exit__'))()


class AbstractAsyncContextManager(abc.ABC):
    '''An abstract base class for asynchronous context managers.'''
    __class_getitem__ = classmethod(GenericAlias)
    
    async def __aenter__(self):
        '''Return `self` upon entering the runtime context.'''
        pass
    # WARNING: Decompyle incomplete

    __aexit__ = (lambda self, exc_type, exc_value, traceback: pass# WARNING: Decompyle incomplete
)()
    __subclasshook__ = (lambda cls, C: if cls is AbstractAsyncContextManager:
_collections_abc._check_methods(C, '__aenter__', '__aexit__'))()


class ContextDecorator(object):
    '''A base class or mixin that enables context managers to work as decorators.'''
    
    def _recreate_cm(self):
        '''Return a recreated instance of self.

        Allows an otherwise one-shot context manager like
        _GeneratorContextManager to support use as
        a decorator via implicit recreation.

        This is a private interface just for _GeneratorContextManager.
        See issue #11647 for details.
        '''
        return self

    
    def __call__(self, func):
        pass
    # WARNING: Decompyle incomplete



class AsyncContextDecorator(object):
    '''A base class or mixin that enables async context managers to work as decorators.'''
    
    def _recreate_cm(self):
        '''Return a recreated instance of self.
        '''
        return self

    
    def __call__(self, func):
        pass
    # WARNING: Decompyle incomplete



class _GeneratorContextManagerBase:
    '''Shared functionality for @contextmanager and @asynccontextmanager.'''
    
    def __init__(self, func, args, kwds):
        pass
    # WARNING: Decompyle incomplete

    
    def _recreate_cm(self):
        return self.__class__(self.func, self.args, self.kwds)



class _GeneratorContextManager(ContextDecorator, AbstractContextManager, _GeneratorContextManagerBase):
    '''Helper for @contextmanager decorator.'''
    
    def __enter__(self):
        del self.args
        del self.kwds
        del self.func
        return next(self.gen)
    # WARNING: Decompyle incomplete

    
    def __exit__(self, typ, value, traceback):
        pass
    # WARNING: Decompyle incomplete



class _AsyncGeneratorContextManager(AsyncContextDecorator, AbstractAsyncContextManager, _GeneratorContextManagerBase):
    '''Helper for @asynccontextmanager decorator.'''
    
    async def __aenter__(self):
        pass
    # WARNING: Decompyle incomplete

    
    async def __aexit__(self, typ, value, traceback):
        pass
    # WARNING: Decompyle incomplete



def contextmanager(func):
    '''@contextmanager decorator.

    Typical usage:

        @contextmanager
        def some_generator(<arguments>):
            <setup>
            try:
                yield <value>
            finally:
                <cleanup>

    This makes this:

        with some_generator(<arguments>) as <variable>:
            <body>

    equivalent to this:

        <setup>
        try:
            <variable> = <value>
            <body>
        finally:
            <cleanup>
    '''
    pass
# WARNING: Decompyle incomplete


def asynccontextmanager(func):
    '''@asynccontextmanager decorator.

    Typical usage:

        @asynccontextmanager
        async def some_async_generator(<arguments>):
            <setup>
            try:
                yield <value>
            finally:
                <cleanup>

    This makes this:

        async with some_async_generator(<arguments>) as <variable>:
            <body>

    equivalent to this:

        <setup>
        try:
            <variable> = <value>
            <body>
        finally:
            <cleanup>
    '''
    pass
# WARNING: Decompyle incomplete


class closing(AbstractContextManager):
    '''Context to automatically close something at the end of a block.

    Code like this:

        with closing(<module>.open(<arguments>)) as f:
            <block>

    is equivalent to this:

        f = <module>.open(<arguments>)
        try:
            <block>
        finally:
            f.close()

    '''
    
    def __init__(self, thing):
        self.thing = thing

    
    def __enter__(self):
        return self.thing

    
    def __exit__(self, *exc_info):
        self.thing.close()



class aclosing(AbstractAsyncContextManager):
    '''Async context manager for safely finalizing an asynchronously cleaned-up
    resource such as an async generator, calling its ``aclose()`` method.

    Code like this:

        async with aclosing(<module>.fetch(<arguments>)) as agen:
            <block>

    is equivalent to this:

        agen = <module>.fetch(<arguments>)
        try:
            <block>
        finally:
            await agen.aclose()

    '''
    
    def __init__(self, thing):
        self.thing = thing

    
    async def __aenter__(self):
        pass
    # WARNING: Decompyle incomplete

    
    async def __aexit__(self, *exc_info):
        pass
    # WARNING: Decompyle incomplete



class _RedirectStream(AbstractContextManager):
    _stream = None
    
    def __init__(self, new_target):
        self._new_target = new_target
        self._old_targets = []

    
    def __enter__(self):
        self._old_targets.append(getattr(sys, self._stream))
        setattr(sys, self._stream, self._new_target)
        return self._new_target

    
    def __exit__(self, exctype, excinst, exctb):
        setattr(sys, self._stream, self._old_targets.pop())



class redirect_stdout(_RedirectStream):
    """Context manager for temporarily redirecting stdout to another file.

        # How to send help() to stderr
        with redirect_stdout(sys.stderr):
            help(dir)

        # How to write help() to a file
        with open('help.txt', 'w') as f:
            with redirect_stdout(f):
                help(pow)
    """
    _stream = 'stdout'


class redirect_stderr(_RedirectStream):
    '''Context manager for temporarily redirecting stderr to another file.'''
    _stream = 'stderr'


class suppress(AbstractContextManager):
    '''Context manager to suppress specified exceptions

    After the exception is suppressed, execution proceeds with the next
    statement following the with statement.

         with suppress(FileNotFoundError):
             os.remove(somefile)
         # Execution still resumes here if the file was already removed
    '''
    
    def __init__(self, *exceptions):
        self._exceptions = exceptions

    
    def __enter__(self):
        pass

    
    def __exit__(self, exctype, excinst, exctb):
        if exctype is not None:
            pass
        return issubclass(exctype, self._exceptions)



class _BaseExitStack:
    '''A base class for ExitStack and AsyncExitStack.'''
    _create_exit_wrapper = (lambda cm, cm_exit: MethodType(cm_exit, cm))()
    _create_cb_wrapper = (lambda callback: pass# WARNING: Decompyle incomplete
)()
    
    def __init__(self):
        self._exit_callbacks = deque()

    
    def pop_all(self):
        '''Preserve the context stack by transferring it to a new instance.'''
        new_stack = type(self)()
        new_stack._exit_ca