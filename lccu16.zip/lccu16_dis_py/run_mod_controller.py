# Source Generated with Decompyle++
# File: run_mod_controller.pyc (Python 3.11)

'''
Tool controller for run_mod
'''
import common
RUN_MOD_COMMAND_NAME = 'run_mod'

def execute(input_file, output_file):
    '''
    Executes run_mod.
    '''
    command_line = []
    command_line.append(RUN_MOD_COMMAND_NAME)
    command_line.append(input_file)
    command_line.append(output_file)
    returncode = common.subprocess_execute(command_line)
    return returncode

