# Source Generated with Decompyle++
# File: lccu16_controller.pyc (Python 3.11)

'''
Tool controller for LCC-U16
'''
import common
LCCU16_OPTION_CODE_MODEL = '-mcmodel='
LCCU16_OPTION_CODE_MODEL_LARGE = 'large'
LCCU16_OPTION_DATA_MODEL = '-mdmodel='
LCCU16_OPTION_TARGET = '--target='
LCCU16_OPTION_TARGET_U16_U8CORE = 'U16_U8CORE'
LCCU16_OPTION_TARGET_U16_U8CORE_N = 'U16_U8CORE_N'
LCCU16_OPTION_DATA_MODEL_NEAR = 'near'
LCCU16_OPTION_DATA_MODEL_FAR = 'far'
LCCU16_OPTION_CPU = '-type='
LCCU16_OPTION_LANGUAGE_STANDARD = '-std='
LCCU16_OPTION_LANGUAGE_STANDARD_C89 = 'c89'
LCCU16_OPTION_LANGUAGE_STANDARD_C99 = 'c99'
LCCU16_OPTION_CHAR_IS_UNSIGNED = '-fno-signed-char'
LCCU16_OPTION_MAX_STRUCT_PACK_ALIGNMENT = '-fpack-struct'
LCCU16_OPTION_SHORT_ENUMS = '-fshort-enums'
LCCU16_OPTION_DEFINE_MACRO = '-D'
LCCU16_OPTION_UNDEFINE_MACRO = '-U'
LCCU16_OPTION_PREPROCESS = '-E'
LCCU16_OPTION_INCLUDE_COMMENTS_IN_PREPROCESS = '-C'
LCCU16_OPTION_INCLUDE_SEARCH_PATH = '-I'
LCCU16_OPTION_OPTIMIZE_0 = '-O0'
LCCU16_OPTION_OPTIMIZE_2 = '-O2'
LCCU16_OPTION_OPTIMIZE_3 = '-O3'
LCCU16_OPTION_OPTIMIZE_Z = '-Oz'
LCCU16_OPTION_OPTIMIZE_LINKED_FILE = '-O-link'
LCCU16_OPTION_SOURCE_LEVEL_DEBUG_INFO = '-g'
LCCU16_OPTION_OUTPUT_FILE_TYPE = '-filetype='
LCCU16_OPTION_OUTPUT_OMFU8_ASSEMBLY = '-lapisomf'
LCCU16_OPTION_USE_RTLU8_ASSEMBLY = '-lapisrtl'
LCCU16_OPTION_DWARF_VERSION = '-gdwarf-'
LCCU16_OPTION_SUPPRESS_ALL_WARNINGS = '-w'
LCCU16_OPTION_ENABLE_ALL_DIAGNOSTICS = '-Weverything'
LCCU16_OPTION_TURN_WARNINGS_INTO_ERROS = '-Werror'
LCCU16_OPTION_TURN_WARNING_FOO_INTO_AN_ERROR = '-Werror='
LCCU16_OPTION_TURN_WARNING_FOO_INTO_A_WARNING = '-Wno-error='
LCCU16_OPTION_DISABLE_WARNING_FOO = '-Wno-'
LCCU16_OPTION_ENABLE_WARNING_FOO = '-W'
LCCU16_OPTION_ERROR_ON_LANGUAGE_EXTENSIONS = '-pedantic-errors'
LCCU16_OPTION_EMIT_LLVM = '-emit-llvm'
LCCU16_OPTION_PREPROCESS_AND_COMPILATION = '-S'
LCCU16_OPTION_OUTPUT_PATH = '-o'
LCCU16_OPTION_DOT_CALLGRAPH = '-dot-callgraph'
LCCU16_OPTION_EMIT_STACK_SIZE = '-stack-size-selection'
LCCU16_OPTION_ENABLE_COMMON_LINKAGE = '-fcommon'
LCCU16_OPTION_TURN_OFF_LOOP_UNROLLER = '-fno-unroll-loops'
LCCU16_OPTION_NO_DISCARD_VALUE_NAMES = '-fno-discard-value-names'
LCCU16_OPTION_NO_INLINE = '-fno-inline'
LCCU16_OPTION_DISABLE_LSR = '-disable-lsr'
LCCU16_OPTION_KEEP_INTERMEDIATE_FILES = '-keep-ll'
LCCU16_OPTION_MODIFY_LLC_OUTPUT = '-modify-llc-output'
LCCU16_OPTION_NO_ERROR_UNSUPPORTED_OPTION = '-no-error-unsupported-option'
LCCU16_OPTION_NO_ERROR_UNSUPPORTED_PARAM = '-no-error-unsupported-param'
LCCU16_OPTION_ENABLE_FUNCTION_SECTIONS = '--function-sections'
LCCU16_OPTION_ENABLE_DATA_SECTIONS = '--data-sections'
LCCU16_OPTION_XCLANG = '-Xclang'
LCCU16_OPTION_XLLVM_LINK = '-Xllvm-link'
LCCU16_OPTION_XOPT = '-Xopt'
LCCU16_OPTION_XLLC = '-Xllc'

def parse_option(option_strs):
    '''
    Parse the string as a LCC-U16 option.
    '''
    has_no_error_unsupported_option = False
    has_no_error_unsupported_param = False
    has_std = False
    request_no_unroll_loops = False
    request_no_discard_value_names = False
    request_disable_lsr = False
    data_model_near = False
    request_no_inline = False
    lapisomf = False
    lapisrtl = False
    std89 = False
    valid_options = []
    invalid_options = []
    unsupported_options = []
    unsupported_param_options = []
# WARNING: Decompyle incomplete

