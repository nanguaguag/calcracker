# Source Generated with Decompyle++
# File: stringprep.pyc (Python 3.11)

__doc__ = 'Library that exposes various tables found in the StringPrep RFC 3454.\n\nThere are two kinds of tables: sets, for which a member test is provided,\nand mappings, for which a mapping function is provided.\n'
from unicodedata import ucd_3_2_0 as unicodedata
# WARNING: Decompyle incomplete
