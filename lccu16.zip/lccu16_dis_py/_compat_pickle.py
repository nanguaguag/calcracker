# Source Generated with Decompyle++
# File: _compat_pickle.pyc (Python 3.11)

# WARNING: Decompyle incomplete
