# Source Generated with Decompyle++
# File: tracemalloc.pyc (Python 3.11)

from collections.abc import Sequence, Iterable
from functools import total_ordering
import fnmatch
import linecache
import os.path as os
import pickle
from _tracemalloc import *
from _tracemalloc import _get_object_traceback, _get_traces

def _format_size(size, sign):
    pass
# WARNING: Decompyle incomplete


class Statistic:
    '''
    Statistic difference on memory allocations between two Snapshot instance.
    '''
    __slots__ = ('traceback', 'size', 'count')
    
    def __init__(self, traceback, size, count):
        self.traceback = traceback
        self.size = size
        self.count = count

    
    def __hash__(self):
        return hash((self.traceback, self.size, self.count))

    
    def __eq__(self, other):
        if not isinstance(other, Statistic):
            return NotImplemented
        if None.traceback == other.traceback:
            if self.size == other.size:
                return self.count == other.count

    
    def __str__(self):
        text = '%s: size=%s, count=%i' % (self.traceback, _format_size(self.size, False), self.count)
        if self.count:
            average = self.size / self.count
            text += ', average=%s' % _format_size(average, False)
        return text

    
    def __repr__(self):
        return '<Statistic traceback=%r size=%i count=%i>' % (self.traceback, self.size, self.count)

    
    def _sort_key(self):
        return (self.size, self.count, self.traceback)



class StatisticDiff:
    '''
    Statistic difference on memory allocations between an old and a new
    Snapshot instance.
    '''
    __slots__ = ('traceback', 'size', 'size_diff', 'count', 'count_diff')
    
    def __init__(self, traceback, size, size_diff, count, count_diff):
        self.traceback = traceback
        self.size = size
        self.size_diff = size_diff
        self.count = count
        self.count_diff = count_diff

    
    def __hash__(self):
        return hash((self.traceback, self.size, self.size_diff, self.count, self.count_diff))

    
    def __eq__(self, other):
        if not isinstance(other, StatisticDiff):
            return NotImplemented
        if None.traceback == other.traceback:
            if self.size == other.size:
                if self.size_diff == other.size_diff:
                    if self.count == other.count:
                        return self.count_diff == other.count_diff

    
    def __str__(self):
        text = '%s: size=%s (%s), count=%i (%+i)' % (self.traceback, _format_size(self.size, False), _format_size(self.size_diff, True), self.count, self.count_diff)
        if self.count:
            average = self.size / self.count
            text += ', average=%s' % _format_size(average, False)
        return text

    
    def __repr__(self):
        return '<StatisticDiff traceback=%r size=%i (%+i) count=%i (%+i)>' % (self.traceback, self.size, self.size_diff, self.count, self.count_diff)

    
    def _sort_key(self):
        return (abs(self.size_diff), self.size, abs(self.count_diff), self.count, self.traceback)



def _compare_grouped_stats(old_group, new_group):
    statistics = []
# WARNING: Decompyle incomplete

Frame = <NODE:12>()
Traceback = <NODE:12>()

def get_object_traceback(obj):
    '''
    Get the traceback where the Python object *obj* was allocated.
    Return a Traceback instance.

    Return None if the tracemalloc module is not tracing memory allocations or
    did not trace the allocation of the object.
    '''
    frames = _get_object_traceback(obj)
# WARNING: Decompyle incomplete


class Trace:
    '''
    Trace of a memory block.
    '''
    __slots__ = ('_trace',)
    
    def __init__(self, trace):
        self._trace = trace

    domain = (lambda self: self._trace[0])()
    size = (lambda self: self._trace[1])()
    traceback = (lambda self: pass# WARNING: Decompyle incomplete
)()
    
    def __eq__(self, other):
        if not isinstance(other, Trace):
            return NotImplemented
        return None._trace == other._trace

    
    def __hash__(self):
        return hash(self._trace)

    
    def __str__(self):
        return f'''{self.traceback!s}: {_format_size(self.size, False)!s}'''

    
    def __repr__(self):
        return f'''<Trace domain={self.domain!s} size={_format_size(self.size, False)!s}, traceback={self.traceback!r}>'''



class _Traces(Sequence):
    
    def __init__(self, traces):
        Sequence.__init__(self)
        self._traces = traces

    
    def __len__(self):
        return len(self._traces)

    
    def __getitem__(self, index):
        if isinstance(index, slice):
            return (lambda .0: pass# WARNING: Decompyle incomplete
)(self._traces[index]())
        return None(self._traces[index])

    
    def __contains__(self, trace):
        return trace._trace in self._traces

    
    def __eq__(self, other):
        if not isinstance(other, _Traces):
            return NotImplemented
        return None._traces == other._traces

    
    def __repr__(self):
        return '<Traces len=%s>' % len(self)



def _normalize_filename(filename):
    filename = os.path.normcase(filename)
    if filename.endswith('.pyc'):
        filename = filename[:-1]
    return filename


class BaseFilter:
    
    def __init__(self, inclusive):
        self.inclusive = inclusive

    
    def _match(self, trace):
        raise NotImplementedError



class Filter(BaseFilter):
    pass
# WARNING: Decompyle incomplete


class DomainFilter(BaseFilter):
    pass
# WARNING: Decompyle incomplete


class Snapshot:
    '''
    Snapshot of traces of memory blocks allocated by Python.
    '''
    
    def __init__(self, traces, traceback_limit):
        self.traces = _Traces(traces)
        self.traceback_limit = traceback_limit

    
    def dump(self, filename):
        '''
        Write the snapshot into a file.
        '''
        pass
    # WARNING: Decompyle incomplete

    load = (lambda filename: pass# WARNING: Decompyle incomplete
)()
    
    def _filter_trace(self, include_filters, exclude_filters, trace):
        pass
    # WARNING: Decompyle incomplete

    
    def filter_traces(self, filters):
        '''
        Create a new Snapshot instance with a filtered traces sequence, filters
        is a list of Filter or DomainFilter instances.  If filters is an empty
        list, return a new Snapshot instance with a copy of the traces.
        '''
        pass
    # WARNING: Decompyle incomplete

    
    def _group_by(self, key_type, cumulative):
        if key_type not in ('traceback', 'filename', 'lineno'):
            raise ValueError(f'''unknown key_type: {key_type!r}''')
        if None and key_type not in ('lineno', 'filename'):
            raise ValueError('cumulative mode cannot by used with key type %r' % key_type)
        stats = None
        tracebacks = { }
    # WARNING: Decompyle incomplete

    
    def statistics(self, key_type, cumulative = (False,)):
        '''
        Group statistics by key_type. Return a sorted list of Statistic
        instances.
        '''
        grouped = self._group_by(key_type, cumulative)
        statistics = list(grouped.values())
        statistics.sort(reverse = True, key = Statistic._sort_key)
        return statistics

    
    def compare_to(self, old_snapshot, key_type, cumulative = (False,)):
        '''
        Compute the differences with an old snapshot old_snapshot. Get
        statistics as a sorted list of StatisticDiff instances, grouped by
        group_by.
        '''
        new_group = self._group_by(key_type, cumulative)
        old_group = old_snapshot._group_by(key_type, cumulative)
        statistics = _compare_grouped_stats(old_group, new_group)
        statistics.sort(reverse = True, key = StatisticDiff._sort_key)
        return statistics



def take_snapshot():
    '''
    Take a snapshot of traces of memory blocks allocated by Python.
    '''
    if not is_tracing():
        raise RuntimeError('the tracemalloc module must be tracing memory allocations to take a snapshot')
    traces = None()
    traceback_limit = get_traceback_limit()
    return Snapshot(traces, traceback_limit)

