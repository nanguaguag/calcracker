# Source Generated with Decompyle++
# File: lccu16_toolchain.pyc (Python 3.11)

'''
Toolchain controller for LLVM
'''
import os
from collections import namedtuple
import common
import lccu16_controller
import clang_controller
import llvm_link_controller
import opt_controller
import llc_controller
import run_mod_controller
Params = namedtuple('Params', [
    'output_dir',
    'output_filename',
    'file_c',
    'option_lccu16'])
OutputInfo = namedtuple('OutputInfo', [
    'output_dirs',
    'output_dir_common',
    'output_base_filename',
    'output_ext'])
Flags = namedtuple('Flags', [
    'only_preprocess',
    'use_llvm_link',
    'use_run_mod',
    'keep_intermediate_files'])
DEFAULT_OUTPUT_DIR = './'
CLANG_OUTPUT_FILENAME_SUFIX = '_clang'
CLANG_OUTPUT_FILE_EXT = '.ll'
CLANG_PREPROCESS_OUTPUT_FILE_EXT = '.i'
LLVM_LINK_OUTPUT_FILENAME_SUFIX = '_llvmlink'
LLVM_LINK_OUTPUT_FILE_EXT = '.ll'
OPT_OUTPUT_FILENAME_SUFIX = '_opt'
OPT_OUTPUT_FILE_EXT = '.ll'
LLC_OUTPUT_FILENAME_SUFIX = '_llc'
COMMND_LINE_SEPARATOR = ','
DEFAULT_OUTPUT_EXT = '.asm'

def parse_command_line(argc, argv):
    '''
    Parses command line parameters.
    '''
    state = 0
    options = list()
    files = list()
    arg_pos = 1
# WARNING: Decompyle incomplete


def get_output_path(option_strs, dir_name, file_name):
    '''
    Gets the output directory and file name.
    '''
    (lccu16_options, invalid_options) = lccu16_controller.parse_option(option_strs)
# WARNING: Decompyle incomplete


def control_files(files, keep_files):
    '''
    Removes the intermediate file according to the settings.
    '''
    pass
# WARNING: Decompyle incomplete


def convert_option_lccu16_to_clang(lccu16_options):
    '''
    Converts LCC-U16 options to clang options.
    '''
    clang_options = []
    source_level_debug_flag = False
    gdwrf_version = '4'
# WARNING: Decompyle incomplete


def execute_clang(lccu16_options, input_paths, output_dirs, only_preprocess):
    '''
    Executes clang.
    '''
    output_paths = []
# WARNING: Decompyle incomplete


def convert_option_lccu16_to_llvm_link(lccu16_options):
    '''
    Converts LCC-U16 options to llvm-link options.
    '''
    llvm_link_options = []
# WARNING: Decompyle incomplete


def execute_llvm_link(lccu16_options, input_paths, output_dir, output_filename):
    '''
    Executes llvm-link.
    '''
    options = convert_option_lccu16_to_llvm_link(lccu16_options)
    output_path = os.path.join(output_dir, output_filename)
    output_path = common.normpath(output_path)
    options.append(llvm_link_controller.LLVM_LINK_OPTION_S)
    options.append(llvm_link_controller.LLVM_LINK_OPTION_OUTPUT_FILE + output_path)
    return_code = llvm_link_controller.execute(options, input_paths)
    if return_code != common.RETURN_CODE_SUCCESS:
        return (return_code, output_path)
    return (None.RETURN_CODE_SUCCESS, output_path)


def convert_option_lccu16_to_opt(lccu16_options, origin_filename):
    '''
    Converts LCC-U16 options to opt options.
    '''
    opt_options = []
# WARNING: Decompyle incomplete


def execute_opt(lccu16_options, input_path, output_dir, output_filename):
    '''
    Executes opt.
    '''
    origin_filename = output_filename[:-7]
    options = convert_option_lccu16_to_opt(lccu16_options, origin_filename)
    output_path = os.path.join(output_dir, output_filename)
    output_path = common.normpath(output_path)
    options.append(opt_controller.OPT_OPTION_OUTPUT_FILE + output_path)
    return_code = opt_controller.execute(options, input_path)
    if return_code != common.RETURN_CODE_SUCCESS:
        return (return_code, output_path)
    return (None.RETURN_CODE_SUCCESS, output_path)


def convert_option_lccu16_to_llc(lccu16_options):
    '''
    Converts LCC-U16 options to llc options.
    '''
    llc_options = []
# WARNING: Decompyle incomplete


def execute_llc(lccu16_options, input_path, output_dir, output_filename):
    '''
    Executes llc.
    '''
    options = convert_option_lccu16_to_llc(lccu16_options)
    output_path = os.path.join(output_dir, output_filename)
    output_path = common.normpath(output_path)
    options.append(llc_controller.LLC_OPTION_OUTPUT_FILE + output_path)
    return_code = llc_controller.execute(options, input_path)
    if return_code != common.RETURN_CODE_SUCCESS:
        return (return_code, output_path)
    return (None.RETURN_CODE_SUCCESS, output_path)


def execute_run_mod(input_path, output_dir, output_filename):
    '''
    Executes run_mod.
    '''
    output_path = os.path.join(output_dir, output_filename)
    output_path = common.normpath(output_path)
    return_code = run_mod_controller.execute(input_path, output_path)
    if return_code != common.RETURN_CODE_SUCCESS:
        return (return_code, output_path)
    return (None.RETURN_CODE_SUCCESS, output_path)


def get_output_info(output_dirs, output_filename):
    '''
    Gets output information.
    '''
    output_dir_common = output_dirs.get(common.PARAM_KEY_COMMON, DEFAULT_OUTPUT_DIR)
    file_path_tuple = common.split_file_path(output_filename)
    output_base_filename = file_path_tuple[1]
    output_ext = file_path_tuple[2]
    return OutputInfo(output_dirs, output_dir_common, output_base_filename, output_ext)


def get_flags(lccu16_options_common):
    '''
    Gets flags.
    '''
    only_preprocess = (lambda .0: pass# WARNING: Decompyle incomplete
) in lccu16_options_common()
    use_llvm_link = (lambda .0: pass# WARNING: Decompyle incomplete
) in lccu16_options_common()
    use_run_mod = (lambda .0: pass# WARNING: Decompyle incomplete
) in lccu16_options_common()
    keep_intermediate_files = (lambda .0: pass# WARNING: Decompyle incomplete
) in lccu16_options_common()
    return Flags(only_preprocess, use_llvm_link, use_run_mod, keep_intermediate_files)


def execute(params):
    '''
    Executes LLVM toolchain.
    '''
    output_info = get_output_info(params.output_dir, params.output_filename)
    lccu16_options = dict()
    for key, value in params.option_lccu16.items():
        (lccu16_options[key], invalid_options) = lccu16_controller.parse_option(value)
        if invalid_options:
            invalid_strs = invalid_options()
            common.print_message(common.MESSAGE_TYPE_ERROR, "Invalid command line option '" + "', '".join(invalid_strs) + "'.")
            
            return (lambda .0: pass# WARNING: Decompyle incomplete
), common.RETURN_CODE_FAILURE
        get_flags(lccu16_options_common) = lccu16_options.get(common.PARAM_KEY_COMMON, [])
        intermediate_files = []
    input_paths = params.file_c if flags.use_llvm_link else [
        params.file_c[0]]
    (return_code, output_paths) = execute_clang(lccu16_options, input_paths, output_info.output_dirs, flags.only_preprocess)
    if not flags.only_preprocess:
        intermediate_files.extend(output_paths)
    if return_code != common.RETURN_CODE_SUCCESS:
        return_code = common.RETURN_CODE_FAILURE
    if return_code != common.RETURN_CODE_SUCCESS or flags.only_preprocess:
        control_files(intermediate_files, flags.keep_intermediate_files)
        return return_code
    if None.use_llvm_link:
        input_paths = output_paths
        output_filename = output_info.output_base_filename + LLVM_LINK_OUTPUT_FILENAME_SUFIX + LLVM_LINK_OUTPUT_FILE_EXT
        (return_code, output_path) = execute_llvm_link(lccu16_options_common, input_paths, output_info.output_dir_common, output_filename)
        intermediate_files.append(output_path)
        if return_code != common.RETURN_CODE_SUCCESS:
            control_files(intermediate_files, flags.keep_intermediate_files)
            return common.RETURN_CODE_FAILURE
    input_path = output_path if None.use_llvm_link else output_paths[0]
    output_filename = output_info.output_base_filename + OPT_OUTPUT_FILENAME_SUFIX + OPT_OUTPUT_FILE_EXT
    (return_code, output_path) = execute_opt(lccu16_options_common, input_path, output_info.output_dir_common, output_filename)
    intermediate_files.append(output_path)
    if return_code != common.RETURN_CODE_SUCCESS:
        control_files(intermediate_files, flags.keep_intermediate_files)
        return common.RETURN_CODE_FAILURE
    input_path = None
    output_filename = output_info.output_base_filename + LLC_OUTPUT_FILENAME_SUFIX + output_info.output_ext if flags.use_run_mod else output_info.output_base_filename + output_info.output_ext
    (return_code, output_path) = execute_llc(lccu16_options_common, input_path, output_info.output_dir_common, output_filename)
    if return_code != common.RETURN_CODE_SUCCESS:
        intermediate_files.append(output_path)
        control_files(intermediate_files, flags.keep_intermediate_files)
        return common.RETURN_CODE_FAILURE
    if None.use_run_mod:
        intermediate_files.append(output_path)
        input_path = output_path
        output_filename = output_info.output_base_filename + output_info.output_ext
        (return_code, output_path) = execute_run_mod(input_path, output_info.output_dir_common, output_filename)
        if return_code != common.RETURN_CODE_SUCCESS:
            intermediate_files.append(output_path)
            control_files(intermediate_files, flags.keep_intermediate_files)
            return common.RETURN_CODE_FAILURE
        None(intermediate_files, flags.keep_intermediate_files)
        return common.RETURN_CODE_SUCCESS

