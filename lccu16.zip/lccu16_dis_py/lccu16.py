# Source Generated with Decompyle++
# File: lccu16.pyc (Python 3.11)

'''
LCC-U16 Driver : Control user interfase.
'''
import sys
import common
import lccu16_toolchain
import warnings
warnings.filterwarnings('ignore')
CDRV_DEFAULT_OUTPUT_DIR = './'
CDRV_DEFAULT_OUTPUT_BASE_FILENAME = 'lccu16'
CDRV_DEFAULT_OUTPUT_FILENAME = CDRV_DEFAULT_OUTPUT_BASE_FILENAME + '.asm'

def main():
    '''
    Analyzes option setting file or command line arguments,
    gets option settings for each Toolchain, input file, and Tool,
    and executes specified Toolchain.
    '''
    argv = sys.argv
    argc = len(argv)
    if argc == 2 and argv[1].startswith('@'):
        option_file_path = argv[1][len('@'):]
        file_params = common.parse_option_file(option_file_path)
        if not file_params:
            common.print_message(common.MESSAGE_TYPE_ERROR, 'Failed to parse the option setting file.')
            sys.exit(common.RETURN_CODE_FAILURE)
        tmp_file_c = common.get_sub_param_values(file_params, common.CDRV_KEY_FILE_C, common.PARAM_KEY_COMMON)
        if not tmp_file_c:
            common.print_message(common.MESSAGE_TYPE_ERROR, 'Invalid option setting file.')
            sys.exit(common.RETURN_CODE_FAILURE)
        else:
            file_params = lccu16_toolchain.parse_command_line(argc, argv)
            if not file_params:
                common.print_message(common.MESSAGE_TYPE_ERROR, 'Invalid command line parameter.')
                sys.exit(common.RETURN_CODE_FAILURE)
    return_code = common.RETURN_CODE_FAILURE
    toolchain = common.get_sub_param_top_value(file_params, common.CDRV_KEY_TOOLCHAIN, common.PARAM_KEY_COMMON, '')
    if toolchain == common.CDRV_KEY_TOOLCHAIN_LCCU16:
        output_dir = common.get_sub_param_top_value_all(file_params, common.CDRV_KEY_OUTPUT_DIR)
        output_filename = common.get_sub_param_top_value(file_params, common.CDRV_KEY_OUTPUT_FILENAME, common.PARAM_KEY_COMMON, CDRV_DEFAULT_OUTPUT_FILENAME)
        file_c = common.get_sub_param_values(file_params, common.CDRV_KEY_FILE_C, common.PARAM_KEY_COMMON)
        option_lccu16 = common.get_sub_params(file_params, common.CDRV_KEY_OPTION_LCCU16)
        params = lccu16_toolchain.Params(output_dir, output_filename, file_c, option_lccu16)
        return_code = lccu16_toolchain.execute(params)
    else:
        common.print_message(common.MESSAGE_TYPE_ERROR, 'Unsupported toolchain.')
    sys.exit(return_code)

if __name__ == '__main__':
    main()
    return None
